<?php get_header(); ?>

<div class="archive">
<h1 class="center">Error 404 - Not Found</h1>
</div>

<?php get_sidebar(); ?>
</div>
<?php get_footer(); ?>