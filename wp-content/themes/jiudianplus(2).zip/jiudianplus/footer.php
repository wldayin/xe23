<div class="footer"><div class="fnav">
<ul>
<li class="about"><a href="<?php echo get_option('home'); ?>/about">关于</a>
<?php wp_list_pages('title_li=&exclude=1' ); ?>
</ul>

</div>&copy; Copyright 2008-2009 <?php bloginfo('name'); ?> All rights reserved. Powered by <a href="http://wordpress.org/" target="_blank">Wordpress</a>. Design by <a href="http://9.douban.com/">douban</a>. Theme by <a href="http://9yls.net/">9yls.net</a></div>
<?php wp_footer(); ?>
</body></html>